print ("Cálculo de la media de dos números")
num1 = input ("Escriba un número: ")
num2 = input ("Escriba otro número: ")
media = (float(num1) + float(num2)) / 2
media = (float(num1) + float(num2)) / 2
print ("La media aritmética de {} y {} es: {}".format( num1, num2, media))