print("Convertidor de grados Celsius a grados Fahrenheit")
celsius = float(input("Escriba una temperatura en grados Celsius: "))
farenheit = celsius * 1.8 + 32;
print("{:.0f} ºC son {:.0f} ºF".format(celsius, farenheit))